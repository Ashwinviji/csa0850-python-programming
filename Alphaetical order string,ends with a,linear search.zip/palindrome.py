n = input("Enter the string : ")
r= n[::-1]
if n==r:
    print(r+ "  THE GIVEN STRING IS A PALINDROME")
else:
    print(r+ "  THE GIVEN STRING IS NOT A PALINDROME")


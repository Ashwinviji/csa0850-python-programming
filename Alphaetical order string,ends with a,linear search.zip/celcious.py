c=float(input("enter the temperature in celsius: "))
f=(c*1.8)+32
print("the value of f is ",f)

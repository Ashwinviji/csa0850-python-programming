value1,value2,value3=10,30,40
max=0
if value1>=value2 and value1>=value3:
    print(value1)
elif value2>=value1 and value2>=value3:
    print(value2)
else:
    print(value3)

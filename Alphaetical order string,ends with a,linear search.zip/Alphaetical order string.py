n=input("enter a string : ")
words =n.split()
words.sort()
for word in words:
    print(word)

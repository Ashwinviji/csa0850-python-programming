n= int(input("Enter the Number: "))
i=0
sum = 0
while(i<=n):
 sum=sum+i
 i=i+1
print(sum)

List = [120, 50, 89, 170, 45, 250, 450, 340]
print("List = ",List)
n = 4
List.sort()
print("Largest integers from the List = ",List[-n:])

Principal_amount=int(input("Enter the principal amount:"))
Year=int(input("Enter number of years:"))
Rate_of_interest=float(input("Enter the rate of interest:"))
Simple_interest=(Principal_amount * Year * Rate_of_interest)/100
print("The simple interest is:",Simple_interest)

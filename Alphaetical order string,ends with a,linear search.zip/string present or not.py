string = "hello world"  
index = string.find('o')  
if index != -1:  
    print("The character 'o' is present in the string at: ", index)  
else:  
    print('The character is not present in the string')

a=int(input("enter the number"))
b=int(input("enter the value"))
sum=a+b
if(sum<5):
    print("sum is less then 5")
if(sum>5):
    print("sum is grether then5")
else:
    sum=5
    print("sum is equal to 5")

def Sorting(lst):
    lst2 = sorted(lst, key=len)
    return lst2
lst=["vineetha","python","programming"]
print(Sorting(lst))

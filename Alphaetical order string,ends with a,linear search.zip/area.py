r=int(input("enter the radius: "))
area=3.14*r*r
print("area of circle: ",area)

list = [27,18,89,35,30]
M = 5
N = 7
print("List is: ", list)
print("Numbers divisible by {0} and {1}".format (M, N))
for num in list:
    
    
    if( num%N==0 ):
        print(num)
        
        
        if(num%M==0):
           
          print(num)
list.sort()
print("sorted list: ",list)
